import { ReactNode, useState } from 'react';
import { Link } from 'react-router-dom';
import { useIsMobile } from '@/hooks/use-mobile';

interface CoursesLayoutProps {
  children: ReactNode;
}

export function CoursesLayout({ children }: CoursesLayoutProps) {
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div 
      className="min-h-screen relative"
      style={{ 
        backgroundColor: '#0a0a0a',
        backgroundImage: `
          radial-gradient(circle at top left, #1a0f04 5%, transparent 40%),
          radial-gradient(circle at bottom right, #3b2c10 10%, transparent 50%)
        `
      }}
    >
      {/* Sidebar Toggle */}
      <button 
        onClick={toggleSidebar}
        className="fixed top-[18px] left-[18px] z-[1150] bg-[#2e2b23] border-2 border-[#5a3c1a] rounded-md py-3 px-[18px] font-bold text-[#5a3c1a] shadow-[0_0_15px_#5a3c1a88] transition-colors hover:bg-[#5a3c1a] hover:text-[#1c1a11] hover:shadow-[0_0_20px_#806232aa] cursor-pointer"
        style={{ fontFamily: "'Courier New', Courier, monospace" }}
      >
        MENU
      </button>

      {/* Sidebar */}
      <div 
        className={`fixed top-0 h-screen ${isMobile ? 'w-[240px]' : 'w-[280px]'} bg-[#1a180fdd] pt-20 pb-6 px-6 flex flex-col gap-5 shadow-[4px_0_20px_#5a3c1a88_inset,inset_0_0_10px_#3b2c1088] font-bold text-[#5a3c1a] uppercase tracking-wider rounded-r-lg transition-all duration-300 z-[1140]`}
        style={{ 
          fontFamily: "'Courier New', Courier, monospace",
          left: sidebarOpen ? '0' : '-280px'
        }}
      >
        <h2 className="font-black tracking-widest text-[#5a3c1a] mb-6" style={{ textShadow: '1px 1px 2px #2f1f09' }}>C.X</h2>
        <nav className="flex flex-col">
          <Link to="/" className="text-[#5a3c1a] no-underline my-[15px] text-lg transition-colors hover:text-[#806232] hover:shadow-[0_0_6px_#806232bb] block py-[10px]">\\HOME//</Link>
          <Link to="/courses" className="text-[#5a3c1a] no-underline my-[15px] text-lg transition-colors hover:text-[#806232] hover:shadow-[0_0_6px_#806232bb] block py-[10px]">//COURSES\\</Link>
          <Link to="/audiobooks" className="text-[#5a3c1a] no-underline my-[15px] text-lg transition-colors hover:text-[#806232] hover:shadow-[0_0_6px_#806232bb] block py-[10px]">/AUDIOBOOKS//</Link>
          <Link to="/freebooks" className="text-[#5a3c1a] no-underline my-[15px] text-lg transition-colors hover:text-[#806232] hover:shadow-[0_0_6px_#806232bb] block py-[10px]">\\FREE BOOKS</Link>
        </nav>
      </div>

      {/* Overlay */}
      <div 
        className={`fixed top-0 left-0 w-full h-full bg-black/90 z-[1130] transition-opacity duration-300 ${sidebarOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}
        onClick={() => setSidebarOpen(false)}
      />

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-[#12100cdd] backdrop-blur-md py-5 px-6 text-center font-black text-xl text-[#5a3c1a] tracking-widest shadow-[inset_0_-2px_4px_#3b2c10cc] z-[1100]" style={{ fontFamily: "'Courier New', Courier, monospace" }}>
        <span>PREMIUM COURSES </span><span className="text-[#3b2c10]">WE NEVER PASS $50</span>
      </header>

      {/* Main Content */}
      <main className="pt-[100px] pb-[60px]">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-[#12100cdd] text-[#3b2c10cc] text-center py-[18px] px-[15px] text-sm border-t border-[#5a3c1a] mt-10" style={{ fontFamily: "'Courier New', Courier, monospace", letterSpacing: '0.06em' }}>
        <div className="font-bold text-[#5a3c1a] mb-2">Co-Founders: Ignacio Chamboko &amp; Don Kyono</div>
        <div className="mb-2">
          <Link to="/privacy" className="text-[#5a3c1a] font-bold mx-2 no-underline hover:text-[#806232]">Privacy Policy</Link> |
          <Link to="/terms" className="text-[#5a3c1a] font-bold mx-2 no-underline hover:text-[#806232]">Terms &amp; Conditions</Link> |
          <Link to="/refund" className="text-[#5a3c1a] font-bold mx-2 no-underline hover:text-[#806232]">Refund Policy</Link> |
          <Link to="/dmca" className="text-[#5a3c1a] font-bold mx-2 no-underline hover:text-[#806232]">DMCA &amp; Copyright</Link>
        </div>
        <div>Email: <a href="mailto:Coursexwagon@gmail.com" className="text-[#5a3c1a] font-bold hover:text-[#806232] no-underline">Coursexwagon@gmail.com</a></div>
      </footer>
    </div>
  );
}