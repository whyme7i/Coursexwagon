import { useEffect } from 'react';

interface VideoModalProps {
  videoUrl: string;
  onClose: () => void;
  isOpen: boolean;
}

export function VideoModal({ videoUrl, onClose, isOpen }: VideoModalProps) {
  // Close modal with escape key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleEsc);
    
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black/95 z-[1200]"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="Course Trailer Video"
    >
      <button 
        className="fixed top-5 right-6 bg-[#5a3c1a] border-none rounded-full w-[45px] h-[45px] text-2xl text-[#12100c] cursor-pointer font-black shadow-[0_0_20px_#806232cc] hover:bg-[#806232] z-[1250]"
        onClick={onClose}
        aria-label="Close Trailer"
      >
        &times;
      </button>
      <video
        controls
        autoPlay
        className="max-w-[90vw] max-h-[80vh] rounded-[15px] shadow-[0_0_30px_#5a3c1a]"
        src={videoUrl}
        onError={(e) => {
          const target = e.target as HTMLVideoElement;
          console.error("Video failed to load:", videoUrl);
          target.poster = 'https://placehold.co/800x450/1a0f04/5a3c1a?text=Video+Unavailable';
        }}
      />
    </div>
  );
}