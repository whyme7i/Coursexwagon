interface CourseCardProps {
  id: string;
  title: string;
  image: string;
  description?: string;
  price?: string;
  category?: string;
  level?: string;
  onWatchTrailer: (id: string) => void;
  purchaseLink: string;
}

export function CourseCard({
  id,
  title,
  image,
  description,
  price,
  category,
  level,
  onWatchTrailer,
  purchaseLink
}: CourseCardProps) {
  return (
    <div 
      className="bg-[#1a180fdd] rounded-[15px] p-5 flex flex-col items-center shadow-[0_0_15px_#5a3c1a88,inset_0_0_15px_#3b2c10cc] hover:shadow-[0_0_25px_#806232cc,inset_0_0_20px_#806232cc] transition-shadow"
      tabIndex={0}
    >
      <div className="relative w-full aspect-video mb-4 overflow-hidden rounded-xl">
        <img 
          src={image} 
          alt={`${title} Banner`} 
          className="w-full h-full object-cover rounded-xl shadow-[0_0_15px_#5a3c1a]"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = 'https://placehold.co/600x340/1a0f04/5a3c1a?text=Course+Image';
          }}
        />
        {level && (
          <span className="absolute top-2 right-2 bg-[#5a3c1a]/80 text-[#12100c] text-xs font-bold py-1 px-2 rounded-full">
            {level}
          </span>
        )}
      </div>
      
      <h3 className="font-black text-xl text-[#5a3c1a] mb-2 text-center tracking-wide" style={{ fontFamily: "'Courier New', Courier, monospace" }}>
        {title}
      </h3>
      
      {description && (
        <p className="text-[#5a3c1a] text-center mb-3 text-sm line-clamp-2">
          {description}
        </p>
      )}

      <div className="flex items-center justify-center gap-2 mt-1 mb-3">
        <span className="text-[#806232] font-bold">{price}</span>
        {category && (
          <span className="bg-[#3b2c10] text-[#806232] text-xs py-1 px-2 rounded">
            {category}
          </span>
        )}
      </div>
      
      <div className="mt-auto w-full flex flex-col gap-3">
        <button 
          className="w-full bg-[#7c1f00] text-white border-none py-3 px-7 rounded-[40px] font-bold cursor-pointer shadow-[0_0_20px_#7c1f0044] hover:bg-[#a33500] transition-colors text-center"
          style={{ fontFamily: "'Courier New', Courier, monospace" }}
          onClick={() => onWatchTrailer(id)}
          aria-label={`Watch trailer for ${title}`}
        >
          Watch Trailer
        </button>
        <a 
          href={purchaseLink} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="w-full bg-[#5a3c1a] text-[#1c1a11] border-none py-3 px-7 rounded-[40px] font-bold cursor-pointer shadow-[0_0_20px_#806232cc] hover:bg-[#806232] hover:text-[#12100c] transition-colors text-center no-underline"
          style={{ fontFamily: "'Courier New', Courier, monospace" }}
          aria-label={`Buy ${title} now`}
        >
          Buy Now
        </a>
      </div>
    </div>
  );
}