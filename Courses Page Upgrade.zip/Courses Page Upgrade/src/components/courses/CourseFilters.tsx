import { useIsMobile } from '@/hooks/use-mobile';

interface CourseFiltersProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filter: string;
  setFilter: (filter: string) => void;
}

export function CourseFilters({ 
  searchQuery, 
  setSearchQuery, 
  filter, 
  setFilter 
}: CourseFiltersProps) {
  const isMobile = useIsMobile();

  return (
    <div className={`mb-8 ${isMobile ? 'flex flex-col' : 'flex flex-row'} gap-4`}>
      <div className="relative flex-1">
        <input
          type="text"
          placeholder="Search courses..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-[#1a180fdd] text-[#5a3c1a] border-2 border-[#5a3c1a] rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#806232] placeholder-[#3b2c10]"
          style={{ fontFamily: "'Courier New', Courier, monospace" }}
        />
        {searchQuery && (
          <button 
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5a3c1a] hover:text-[#806232]"
            onClick={() => setSearchQuery('')}
            aria-label="Clear search"
          >
            ✕
          </button>
        )}
      </div>
      <select
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        className="bg-[#1a180fdd] text-[#5a3c1a] border-2 border-[#5a3c1a] rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#806232]"
        style={{ fontFamily: "'Courier New', Courier, monospace" }}
        aria-label="Filter courses by category"
      >
        <option value="all">All Categories</option>
        <option value="business">Business</option>
        <option value="technology">Technology</option>
        <option value="marketing">Marketing</option>
        <option value="writing">Writing</option>
      </select>
    </div>
  );
}