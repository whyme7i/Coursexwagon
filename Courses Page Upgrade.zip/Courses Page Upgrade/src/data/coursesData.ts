export interface Course {
  id: string;
  title: string;
  image: string;
  trailerVideo: string;
  purchaseLink: string;
  description: string;
  price: string;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
  featured?: boolean;
}

export const courses: Course[] = [
  {
    id: 'freelancing',
    title: 'Freelancing Course',
    image: '/images/COURSES BANNERS/1.FREELANCING COURSE.jpeg',
    trailerVideo: '/videos/FREELANCING TRAILER.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/wbtuj',
    description: 'Launch your successful freelancing career with proven strategies and client acquisition techniques.',
    price: '$49.99',
    category: 'Business',
    level: 'All Levels',
    featured: true
  },
  {
    id: 'ecommerce',
    title: 'E-Commerce Course',
    image: '/images/COURSES BANNERS/2.ECOMARCE COURSE .jpeg',
    trailerVideo: '/videos/E-COMMERCE TRAILER.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/ytbqq',
    description: 'Build and scale your online store with effective marketing and optimization strategies.',
    price: '$47.99',
    category: 'Business',
    level: 'Beginner'
  },
  {
    id: 'aicontent',
    title: 'AI Content Course',
    image: '/images/COURSES BANNERS/3.AI CONTENT COURSE.jpeg',
    trailerVideo: '/videos/ai promoting trailer.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/zszqo',
    description: 'Master AI tools to create engaging content that drives traffic and conversions.',
    price: '$45.99',
    category: 'Technology',
    level: 'Intermediate',
    featured: true
  },
  {
    id: 'aicreation',
    title: 'AI Content Creation Course',
    image: '/images/COURSES BANNERS/4.AI CONTENT CREATION COURSE.jpeg',
    trailerVideo: '/videos/Lesson 1 What is Content.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/nlgein',
    description: 'Learn advanced techniques for AI-powered content creation across multiple platforms.',
    price: '$49.99',
    category: 'Technology',
    level: 'Advanced'
  },
  {
    id: 'copywritingtrw',
    title: 'Copywriting Course by TRW',
    image: '/images/COURSES BANNERS/5.COPYWRITING COURSE BY TRW.jpeg',
    trailerVideo: '/videos/COPYWRITING TRAILER.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/vgoqr',
    description: 'Learn the art of persuasive writing from industry expert TRW.',
    price: '$39.99',
    category: 'Marketing',
    level: 'Beginner'
  },
  {
    id: 'copywritingpaid',
    title: 'Copywriting Paid Course',
    image: '/images/COURSES BANNERS/6.COPYWRITING PAID COURSE.jpeg',
    trailerVideo: '/videos/COPYWRITING PAID COURSE TRAILER.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/wiiis',
    description: 'Master the psychology behind high-converting copy that sells.',
    price: '$42.99',
    category: 'Marketing',
    level: 'Intermediate',
    featured: true
  },
  {
    id: 'writingtoolbox',
    title: 'Writing Tool Box',
    image: '/images/COURSES BANNERS/7.WRITING TOOL BOX.jpeg',
    trailerVideo: '/videos/TOOL BOX TRAILER.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/buqrew',
    description: 'Essential tools and templates for creating engaging written content.',
    price: '$36.99',
    category: 'Writing',
    level: 'All Levels'
  },
  {
    id: 'affiliatemarketing',
    title: 'Affiliate Marketing',
    image: '/images/COURSES BANNERS/8.AFFILIATE MARKETING.jpeg',
    trailerVideo: '/videos/AFFILIATE MARKETING TRAILER.mp4',
    purchaseLink: 'https://masteredpath.gumroad.com/l/vipisi',
    description: 'Learn how to generate passive income through strategic affiliate partnerships.',
    price: '$44.99',
    category: 'Business',
    level: 'Intermediate'
  },
];