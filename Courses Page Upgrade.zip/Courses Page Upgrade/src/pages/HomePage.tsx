import { Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'

function HomePage() {
  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center gap-6"
      style={{ 
        backgroundColor: '#0a0a0a',
        backgroundImage: `
          radial-gradient(circle at top left, #1a0f04 5%, transparent 40%),
          radial-gradient(circle at bottom right, #3b2c10 10%, transparent 50%)
        `
      }}
    >
      <div className="flex flex-col items-center gap-2 text-center">
        <Sparkles className="w-12 h-12 text-[#5a3c1a]" />
        <h1 className="text-5xl font-black text-[#5a3c1a] tracking-wider mt-4" 
            style={{ fontFamily: "'Courier New', Courier, monospace" }}>
          COURSE.XWAGON
        </h1>
        <p className="text-xl text-[#3b2c10] mt-2" style={{ fontFamily: "'Courier New', Courier, monospace" }}>
          Premium Courses - We Never Pass $50
        </p>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 mt-8">
        <Link to="/courses">
          <Button 
            size="lg" 
            className="bg-[#5a3c1a] text-[#1c1a11] border-none py-6 px-8 rounded-[40px] font-bold shadow-[0_0_20px_#806232cc] hover:bg-[#806232] hover:text-[#12100c]"
            style={{ fontFamily: "'Courier New', Courier, monospace" }}
          >
            Browse Courses
          </Button>
        </Link>
        <Link to="/audiobooks">
          <Button 
            size="lg" 
            variant="outline"
            className="border-2 border-[#5a3c1a] text-[#5a3c1a] py-6 px-8 rounded-[40px] font-bold hover:bg-[#5a3c1a] hover:text-[#1c1a11]"
            style={{ fontFamily: "'Courier New', Courier, monospace" }}
          >
            Audiobooks
          </Button>
        </Link>
      </div>
    </div>
  )
}

export default HomePage 