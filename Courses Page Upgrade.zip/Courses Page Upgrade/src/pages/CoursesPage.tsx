import { useState, useEffect } from 'react';
import { CoursesLayout } from '@/components/layout/CoursesLayout';
import { CourseCard } from '@/components/courses/CourseCard';
import { VideoModal } from '@/components/courses/VideoModal';
import { CourseFilters } from '@/components/courses/CourseFilters';
import { courses } from '@/data/coursesData';
import { useToast } from '@/hooks/use-toast';

export default function CoursesPage() {
  const { toast } = useToast();
  const [activeTrailer, setActiveTrailer] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [featuredCourse, setFeaturedCourse] = useState<string | null>(null);
  
  // Automatically select a random featured course on first load
  useEffect(() => {
    const featured = courses.filter(course => course.featured);
    if (featured.length > 0) {
      const randomIndex = Math.floor(Math.random() * featured.length);
      setFeaturedCourse(featured[randomIndex].id);
    }
  }, []);

  // Filter courses based on category and search query
  const filteredCourses = courses.filter(course => {
    const matchesCategory = filter === 'all' || course.category.toLowerCase() === filter.toLowerCase();
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         course.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Handle trailer modal
  const openTrailer = (courseId: string) => {
    setActiveTrailer(courseId);
    // Log this action (could be used for analytics)
    console.log(`Trailer opened: ${courseId}`);
  };

  const closeTrailer = () => {
    setActiveTrailer(null);
  };
  
  // Find the active course for the trailer
  const activeCourse = activeTrailer ? courses.find(course => course.id === activeTrailer) : null;

  return (
    <CoursesLayout>
      <div className="container mx-auto px-6">
        {/* Featured course section (if any is featured) */}
        {featuredCourse && (
          <div className="mb-12">
            <h2 className="text-[#806232] text-2xl mb-6 font-black tracking-wide" style={{ fontFamily: "'Courier New', Courier, monospace" }}>
              <span className="inline-block bg-[#3b2c10] px-3 py-1 rounded-md">FEATURED</span> COURSE
            </h2>
            <div className="bg-[#1a180fdd]/70 p-6 rounded-xl shadow-[0_0_30px_#5a3c1a66,inset_0_0_20px_#3b2c1088]">
              {courses.filter(c => c.id === featuredCourse).map(course => (
                <div key={course.id} className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="relative">
                    <img 
                      src={course.image} 
                      alt={`${course.title} Banner`}
                      className="w-full h-full object-cover rounded-xl shadow-[0_0_15px_#5a3c1a]"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = 'https://placehold.co/600x340/1a0f04/5a3c1a?text=Featured+Course';
                      }}
                    />
                    {course.level && (
                      <span className="absolute top-2 right-2 bg-[#5a3c1a]/90 text-[#12100c] text-xs font-bold py-1 px-3 rounded-full">
                        {course.level}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col justify-center">
                    <h3 className="font-black text-2xl text-[#806232] mb-4" style={{ fontFamily: "'Courier New', Courier, monospace" }}>
                      {course.title}
                    </h3>
                    <p className="text-[#5a3c1a] mb-6">
                      {course.description}
                    </p>
                    <div className="flex items-center gap-4 mb-6">
                      <span className="text-[#806232] font-bold text-xl">{course.price}</span>
                      <span className="bg-[#3b2c10] text-[#806232] py-1 px-3 rounded">
                        {course.category}
                      </span>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <button 
                        className="bg-[#7c1f00] text-white border-none py-3 px-7 rounded-[40px] font-bold cursor-pointer shadow-[0_0_20px_#7c1f0044] hover:bg-[#a33500] transition-colors text-center"
                        style={{ fontFamily: "'Courier New', Courier, monospace" }}
                        onClick={() => openTrailer(course.id)}
                      >
                        Watch Trailer
                      </button>
                      <a 
                        href={course.purchaseLink} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="bg-[#5a3c1a] text-[#1c1a11] border-none py-3 px-7 rounded-[40px] font-bold cursor-pointer shadow-[0_0_20px_#806232cc] hover:bg-[#806232] hover:text-[#12100c] transition-colors text-center no-underline"
                        style={{ fontFamily: "'Courier New', Courier, monospace" }}
                        onClick={() => {
                          toast({
                            title: "Redirecting to purchase page",
                            description: `You're being redirected to purchase ${course.title}`,
                            duration: 3000
                          });
                        }}
                      >
                        Buy Now
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Course filters */}
        <CourseFilters 
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          filter={filter}
          setFilter={setFilter}
        />
        
        {/* Main course grid */}
        <h2 className="text-[#5a3c1a] text-xl mb-6 font-bold tracking-wide" style={{ fontFamily: "'Courier New', Courier, monospace" }}>
          ALL COURSES
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredCourses.map(course => (
            <CourseCard
              key={course.id}
              id={course.id}
              title={course.title}
              image={course.image}
              description={course.description}
              price={course.price}
              category={course.category}
              level={course.level}
              onWatchTrailer={openTrailer}
              purchaseLink={course.purchaseLink}
            />
          ))}
        </div>

        {/* No results message */}
        {filteredCourses.length === 0 && (
          <div className="text-center py-12 bg-[#1a180f]/50 rounded-lg">
            <p className="text-[#5a3c1a] text-xl">No courses found matching your criteria</p>
            <button 
              className="mt-4 bg-[#5a3c1a] text-[#1c1a11] border-none py-2 px-4 rounded-[40px] font-bold cursor-pointer shadow-[0_0_10px_#806232cc] hover:bg-[#806232] transition-colors"
              onClick={() => {
                setFilter('all');
                setSearchQuery('');
              }}
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>

      {/* Video trailer modal */}
      {activeCourse && (
        <VideoModal
          videoUrl={activeCourse.trailerVideo}
          onClose={closeTrailer}
          isOpen={!!activeTrailer}
        />
      )}
    </CoursesLayout>
  );
}